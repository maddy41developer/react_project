import React from 'react';

export default function About() {
return(
<React.Fragment>
<h1>Hiii This is the About page</h1>  
<h3>hello Guys</h3>  
</React.Fragment> )
}