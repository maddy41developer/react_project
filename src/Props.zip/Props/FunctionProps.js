
// import './App.css';

function FunctionProps(props) {
    return (
      <div>
     <h1>{props.name}</h1>
      </div>
    );
  }
  
export default FunctionProps;
  
