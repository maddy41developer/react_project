import React from 'react';

export default function Home() {
return(
<>
<h1>Hiii This is the Home page</h1>
</>
)
}
