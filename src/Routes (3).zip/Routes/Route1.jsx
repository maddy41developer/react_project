import React from 'react';

export default function Info() {
return(
<React.Fragment>
<h1>Hiii This is the Info page</h1>    
</React.Fragment> )
}

// packages npm install react-router-dom