import React from 'react';
import ReactDOM from 'react-dom';
class Myclass3 extends React.Component
{
  render()
  {
    return <>
    <h1>Class Component3</h1>
    <h1>From third file</h1>
    </>
  }
}

// ReactDOM.render(<Mynewwebsite />,document.getElementById('root'));
export default Myclass3;