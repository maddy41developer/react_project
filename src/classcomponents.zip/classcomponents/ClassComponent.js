import React from 'react';
import ReactDOM from 'react-dom';
import Myclass2 from './ClassComponent2';
// import Myclass2 from './ClassComponent2';

class Mywebsite extends React.Component
{
  render()
  {
    return <>
    <h1>Welcome</h1>
    <Mysite />
    <Myclass2 />
    </>
  }
}


class Mysite extends React.Component
{
  render()
  {
    return <h1>ThankYou</h1>
  }
}


export default Mywebsite;
